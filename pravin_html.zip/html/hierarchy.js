var hierarchy =
[
    [ "IShape", "class_i_shape.html", [
      [ "Circle", "class_circle.html", null ],
      [ "Rectangle", "class_rectangle.html", null ]
    ] ],
    [ "Shape", "class_shape.html", [
      [ "Circle", "class_circle.html", null ]
    ] ]
];