var class_rectangle =
[
    [ "Rectangle", "class_rectangle.html#a361b04e1812db6a4774273d18198f65d", null ],
    [ "area", "class_rectangle.html#aab6845e3b4fc1cf25333ba35b59087d5", null ],
    [ "perimeter", "class_rectangle.html#a87d72ed0c0a889835949ba32cdebc4f5", null ]
];