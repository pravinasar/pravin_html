var searchData=
[
  ['name_0',['name',['../class_circle.html#a5bf591ce61009efc66c8f06d05148eb5',1,'Circle::name()'],['../class_shape.html#aa91a34940045989f4c7f8ab7e70a7841',1,'Shape::name()']]]
];
