var indexSectionsWithContent =
{
  0: "2acdimnprst~",
  1: "cirs",
  2: "cst",
  3: "acmnpr~",
  4: "s",
  5: "2cdist"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Macros",
  5: "Pages"
};

