var searchData=
[
  ['_7eishape_0',['~IShape',['../class_i_shape.html#abecc7b52521ee60efa01d65a855dd652',1,'IShape']]],
  ['_7eshape_1',['~Shape',['../class_shape.html#ac8ad2fd02e1e94beeb98e65ab795cd56',1,'Shape']]]
];
