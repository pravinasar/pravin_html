var annotated_dup =
[
    [ "Circle", "class_circle.html", "class_circle" ],
    [ "IShape", "class_i_shape.html", "class_i_shape" ],
    [ "Rectangle", "class_rectangle.html", "class_rectangle" ],
    [ "Shape", "class_shape.html", "class_shape" ]
];