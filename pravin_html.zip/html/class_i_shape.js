var class_i_shape =
[
    [ "~IShape", "class_i_shape.html#abecc7b52521ee60efa01d65a855dd652", null ],
    [ "area", "class_i_shape.html#aed742a160acdd13c9cfdeb16e605afea", null ],
    [ "perimeter", "class_i_shape.html#a485f6770c4e56b31c76d368b959b6f00", null ]
];