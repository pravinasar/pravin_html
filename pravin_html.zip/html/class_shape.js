var class_shape =
[
    [ "~Shape", "class_shape.html#ac8ad2fd02e1e94beeb98e65ab795cd56", null ],
    [ "area", "class_shape.html#afeee6df3afb921a347db5faa1349af4d", null ],
    [ "name", "class_shape.html#aa91a34940045989f4c7f8ab7e70a7841", null ],
    [ "perimeter", "class_shape.html#a56921fb8e6d0ad51dc38060fd22acfc5", null ]
];